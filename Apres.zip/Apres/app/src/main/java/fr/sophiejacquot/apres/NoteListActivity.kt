package fr.sophiejacquot.apres

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class NoteListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_list)
    }
}
